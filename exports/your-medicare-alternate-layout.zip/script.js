$(document).ready(function () {
  // --- 1. CONFIG ---
  const audioMap = {
    "#msg1": "msg1",
    "#msg2": "msg2",
    "#msg3": "msg3",
    "#msg7": "msg7",
    "#msg10": "msg10",
    "#msg13": "y_msg7",
    "#msg14": "y_msg8",
    "#msg15": "y_msg9",
    "#msg18": "sorry",
  };

  const MSG_GAP = 500; // ms between each message bubble appearing
  const AUDIO_GAP = 400; // ms of silence between audio clips

  // ─── SINGLE GLOBAL AUDIO QUEUE ───────────────────────────────────────────
  // Only ONE audio object, ONE drain loop. Every showChunk just pushes
  // filenames in. Nothing ever collides or overwrites anything mid-play.
  const player = new Audio();
  player.playbackRate = 1.2;
  let queue = [];
  let draining = false;

  function enqueue(selectors) {
    selectors.forEach((sel) => {
      const f = audioMap[sel];
      if (f) queue.push(f);
    });
    if (!draining) drain();
  }

  function drain() {
    if (queue.length === 0) {
      draining = false;
      return;
    }
    draining = true;
    const file = queue.shift();
    player.src = `audio/${file}.mp3`;
    player.playbackRate = 1.2;
    const next = () => setTimeout(drain, AUDIO_GAP);
    player.onended = next;
    player.onerror = next;
    player.play().catch(next);
  }

  // Call this when user interacts — stops current clip & wipes pending audio
  function clearAudio() {
    queue = [];
    player.pause();
    player.src = "";
    draining = false;
  }
  // ─────────────────────────────────────────────────────────────────────────

  function delay(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function scrollToBottom() {
    $("html, body").animate({ scrollTop: $(document).height() }, "fast");
  }

  // Show messages one by one, queue their audio — fire and forget
  function showChunk(selectors) {
    selectors.forEach((sel, i) => {
      setTimeout(() => {
        $(sel).removeClass("hidden");
        scrollToBottom();
      }, i * MSG_GAP);
    });
    enqueue(selectors);
  }

  function show(sel) {
    $(sel).removeClass("hidden");
    scrollToBottom();
  }

  // --- INTRO ---
  async function startIntro() {
    await delay(800);
    $("#initTyping").remove();

    showChunk(["#msg1", "#msg2", "#msg3"]);

    await delay(3 * MSG_GAP + 400);
    show("#agentBlock2");
    await delay(150);
    showChunk(["#msg7"]);
    await delay(MSG_GAP + 300);
    show("#msg8a");
    scrollToBottom();
  }

  // --- CLICKS ---
  $("button.chat-button").on("click", async function () {
    const step = $(this).data("form-step");
    const value = $(this).data("form-value");

    // Stop whatever is playing / queued — user has moved the flow forward
    clearAudio();

    $(this).closest("div").find(".chat-button").prop("disabled", true);

    // ── Age ───────────────────────────────────────────────────────────────
    if (step === 1) {
      $("#msg8a").addClass("hidden");
      show("#userBlock2");
      value.includes("54") ? show("#msg9-54to75") : show("#msg9-76andOlder");

      await delay(350);
      show("#agentBlock3");
      await delay(150);

      showChunk(["#msg10"]);
      await delay(MSG_GAP + 300);
      show("#msg11");
      scrollToBottom();

      // ── Medicare ──────────────────────────────────────────────────────────
    } else if (step === 2) {
      $("#msg11").addClass("hidden");
      show("#userBlock3");
      value === "Yes" ? show("#msg12Yes") : show("#msg12No");

      await delay(350);
      show("#agentBlock4");
      await delay(150);

      if (value === "Yes") {
        showChunk(["#msg13", "#msg14", "#msg15"]);
        await delay(3 * MSG_GAP + 350);
        show("#msg17");
        scrollToBottom();
      } else {
        showChunk(["#msg18"]);
        await delay(MSG_GAP + 400);
        show("#disconnected");
        scrollToBottom();
      }
    }
  });

  // --- INIT ---
  $("#currentDate").text(
    new Date().toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }),
  );

  startIntro();
});
